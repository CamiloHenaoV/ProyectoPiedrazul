package com.piedrazul.msusermanagement.infra.messaging;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserRegisteredEvent {
    private Long userId;
    private String login;
    private String nombreCompleto;
    private String rol;
}
